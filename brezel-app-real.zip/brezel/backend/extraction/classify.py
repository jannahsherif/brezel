"""
Document classification — decides what *kind* of document this is, so the
field-extraction stage knows which regex rules to apply.

This is deliberately keyword/regex based (zero cost, deterministic, fast).
See `fields.py` docstring for how to swap in a local LLM (Ollama) later
without touching any other part of the pipeline.
"""
from __future__ import annotations

import re

DOCUMENT_KINDS = [
    "insurance",
    "invoice",
    "contract",
    "run_of_show",
    "menu",
    "other",
]

_KEYWORDS: dict[str, list[str]] = {
    "insurance": [
        r"certificate of (liability )?insurance",
        r"\binsurer\b",
        r"\bpolicy number\b",
        r"\bcoi\b",
        r"general liability",
    ],
    "invoice": [
        r"\binvoice\b",
        r"amount due",
        r"\bsubtotal\b",
        r"\bbalance due\b",
        r"payment terms",
    ],
    "contract": [
        r"\bagreement\b",
        r"this contract",
        r"\bwhereas\b",
        r"signed by",
        r"\bsignature\b",
        r"terms and conditions",
    ],
    "run_of_show": [
        r"run.?of.?show",
        r"\bload.?in\b",
        r"\brehearsal\b",
        r"\bcue\b",
        r"\bschedule of events\b",
        r"soundcheck",
    ],
    "menu": [
        r"\bmenu\b",
        r"dietary",
        r"\bvegan\b|\bvegetarian\b|\ballergen\b",
        r"per person",
        r"catering",
    ],
}

_compiled = {
    kind: [re.compile(pat, re.IGNORECASE) for pat in patterns]
    for kind, patterns in _KEYWORDS.items()
}


def classify_document(text: str, filename: str = "") -> str:
    """Return the best-guess document kind, scored by keyword hits."""
    haystack = f"{filename}\n{text}".lower()
    scores = {kind: 0 for kind in _KEYWORDS}

    for kind, patterns in _compiled.items():
        for pat in patterns:
            scores[kind] += len(pat.findall(haystack))

    best_kind, best_score = max(scores.items(), key=lambda kv: kv[1])
    if best_score == 0:
        return "other"
    return best_kind
