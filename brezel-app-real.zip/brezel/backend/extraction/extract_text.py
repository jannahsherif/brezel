"""
Text extraction — the first stage of the pipeline.

Zero-API-cost design:
  * Digital PDFs  -> pdfplumber pulls the embedded text layer directly.
  * Scanned PDFs  -> if pdfplumber comes back nearly empty, we rasterize each
                     page with pdf2image (poppler) and OCR it with Tesseract.
  * Images        -> straight to Tesseract.

Everything here runs locally on the CPU. No network calls, no per-page fees.
"""
from __future__ import annotations

import os
from dataclasses import dataclass

import pdfplumber
import pytesseract
from PIL import Image

MIN_CHARS_PER_PAGE_TO_TRUST_TEXT_LAYER = 40  # below this we assume it's a scan


@dataclass
class ExtractionResult:
    text: str
    used_ocr: bool
    page_count: int


def _extract_pdf_text_layer(path: str) -> tuple[str, int]:
    chunks: list[str] = []
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            chunks.append(page.extract_text() or "")
        page_count = len(pdf.pages)
    return "\n".join(chunks), page_count


def _ocr_pdf(path: str) -> str:
    # Imported lazily: pdf2image needs poppler installed, which is only
    # exercised for scanned documents.
    from pdf2image import convert_from_path

    images = convert_from_path(path, dpi=300)
    return "\n".join(pytesseract.image_to_string(img) for img in images)


def _ocr_image(path: str) -> str:
    return pytesseract.image_to_string(Image.open(path))


def extract_text(path: str) -> ExtractionResult:
    ext = os.path.splitext(path)[1].lower()

    if ext == ".pdf":
        text, page_count = _extract_pdf_text_layer(path)
        avg_chars = len(text.strip()) / max(page_count, 1)
        if avg_chars < MIN_CHARS_PER_PAGE_TO_TRUST_TEXT_LAYER:
            # Likely a scanned PDF with little to no real text layer.
            ocr_text = _ocr_pdf(path)
            if len(ocr_text.strip()) > len(text.strip()):
                return ExtractionResult(text=ocr_text, used_ocr=True, page_count=page_count)
        return ExtractionResult(text=text, used_ocr=False, page_count=page_count)

    if ext in (".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"):
        text = _ocr_image(path)
        return ExtractionResult(text=text, used_ocr=True, page_count=1)

    if ext == ".txt":
        with open(path, "r", errors="ignore") as f:
            text = f.read()
        return ExtractionResult(text=text, used_ocr=False, page_count=1)

    raise ValueError(f"Unsupported file type: {ext}")
