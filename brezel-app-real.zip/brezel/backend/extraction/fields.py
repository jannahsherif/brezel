"""
Field extraction — turns raw text + a document kind into the structured
fields Brezel shows in the Documents register (Document, Date, Vendor,
Risk, etc).

Today this is 100% regex/rules, so it costs nothing to run and needs no
infrastructure beyond the Python process already running.

--- How to upgrade to a local LLM later (Ollama), with zero API cost ---
1. `pip install ollama` and run `ollama serve` + `ollama pull llama3.1` on
   your own box (still $0, just your own CPU/GPU).
2. Add a function here, e.g.:

       import ollama
       def call_ollama(text: str, kind: str) -> dict:
           resp = ollama.chat(model="llama3.1", messages=[{
               "role": "user",
               "content": (
                   "Extract these fields as JSON: vendor, date, amount, "
                   "insurance_expiry, risk. Text:\n" + text[:4000]
               ),
           }])
           return json.loads(resp["message"]["content"])

3. In `extract_fields()` below, call `call_ollama(text, kind)` and merge its
   result over the regex result (regex as a fast, free fallback; LLM only
   for fields regex left blank, or to double check ambiguous ones).

Nothing else in the app needs to change — `extract_fields()` is the only
seam the rest of the pipeline talks to.
"""
from __future__ import annotations

import re
from datetime import date, datetime
from typing import Optional

from dateutil import parser as dateparser

# --- generic regexes, reused across document kinds -------------------------

_DATE_PATTERNS = [
    r"\b\d{4}-\d{2}-\d{2}\b",                          # 2026-08-08
    r"\b\d{1,2}/\d{1,2}/\d{2,4}\b",                     # 8/8/2026
    r"\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d{1,2},?\s+\d{4}\b",
    r"\b\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?,?\s+\d{4}\b",
]
_MONEY_RE = re.compile(r"[$£€]\s?\d[\d,]*(?:\.\d{2})?")
_EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
_PHONE_RE = re.compile(r"\+?\d[\d\s().-]{7,}\d")
_POLICY_RE = re.compile(r"policy\s*(?:no\.?|number)?\s*[:#]?\s*([A-Z0-9-]{5,})", re.IGNORECASE)

_date_res = [re.compile(p, re.IGNORECASE) for p in _DATE_PATTERNS]


def _find_dates(text: str) -> list[str]:
    found: list[str] = []
    for rx in _date_res:
        found.extend(rx.findall(text))
    # de-dupe while preserving order
    seen = set()
    out = []
    for d in found:
        if d not in seen:
            seen.add(d)
            out.append(d)
    return out


def _parse_date_safe(s: str) -> Optional[date]:
    try:
        return dateparser.parse(s, fuzzy=True).date()
    except Exception:
        return None


def _guess_vendor_name(text: str) -> Optional[str]:
    """Heuristic: first substantial non-empty line that isn't a date/money/
    boilerplate — usually a letterhead or 'From:' company name."""
    for raw_line in text.splitlines()[:15]:
        line = raw_line.strip()
        if not line or len(line) < 3:
            continue
        if _MONEY_RE.search(line) or _EMAIL_RE.search(line):
            continue
        if re.match(r"^(page|invoice|date|dear|to whom)", line, re.IGNORECASE):
            continue
        if len(line) > 60:
            continue
        return line
    return None


def _nearby_window(text: str, keyword_re: re.Pattern, before: int = 0, after: int = 100) -> Optional[str]:
    """Text around a keyword match. Mostly forward-looking, since labels like
    'Due date:' or 'expires' are almost always followed by their value, and a
    wide backward window risks picking up an unrelated earlier date/number."""
    m = keyword_re.search(text)
    if not m:
        return None
    start = max(0, m.start() - before)
    end = min(len(text), m.end() + after)
    return text[start:end]


def extract_generic_fields(text: str) -> dict:
    dates = _find_dates(text)
    dates_set = set(dates)
    # The phone regex is deliberately loose (it has to catch many formats),
    # so drop anything that's actually one of the dates we already found.
    phones = [p for p in _PHONE_RE.findall(text) if p.strip() not in dates_set]
    return {
        "dates_found": dates,
        "amounts_found": _MONEY_RE.findall(text)[:10],
        "emails_found": _EMAIL_RE.findall(text)[:5],
        "phones_found": phones[:5],
        "vendor_guess": _guess_vendor_name(text),
    }


def extract_kind_specific_fields(text: str, kind: str) -> dict:
    fields: dict = {}

    if kind == "insurance":
        window = _nearby_window(text, re.compile(r"expir\w*", re.IGNORECASE))
        expiry_dates = _find_dates(window) if window else []
        fields["insurance_expiry"] = expiry_dates[0] if expiry_dates else None
        policy_match = _POLICY_RE.search(text)
        fields["policy_number"] = policy_match.group(1) if policy_match else None

    elif kind == "invoice":
        due_window = _nearby_window(text, re.compile(r"due\s*(date)?", re.IGNORECASE))
        due_dates = _find_dates(due_window) if due_window else []
        fields["due_date"] = due_dates[0] if due_dates else None
        amounts = _MONEY_RE.findall(text)
        fields["total_amount"] = amounts[-1] if amounts else None

    elif kind == "contract":
        fields["signed"] = bool(re.search(r"\bsigned\b", text, re.IGNORECASE))
        sig_window = _nearby_window(text, re.compile(r"\bsigned\b", re.IGNORECASE))
        sig_dates = _find_dates(sig_window) if sig_window else []
        fields["signature_date"] = sig_dates[0] if sig_dates else None

    elif kind == "run_of_show":
        fields["mentions_load_in"] = bool(re.search(r"load.?in", text, re.IGNORECASE))
        fields["mentions_rehearsal"] = bool(re.search(r"rehearsal", text, re.IGNORECASE))

    elif kind == "menu":
        dietary_terms = re.findall(
            r"\b(vegan|vegetarian|gluten.?free|dairy.?free|nut.?free|halal|kosher)\b",
            text,
            re.IGNORECASE,
        )
        fields["dietary_terms_found"] = sorted(set(t.lower() for t in dietary_terms))

    return fields


def compute_risks(kind: str, generic: dict, specific: dict) -> list[dict]:
    """Turn extracted fields into human-readable risk flags."""
    risks: list[dict] = []
    today = date.today()

    if kind == "insurance":
        expiry_str = specific.get("insurance_expiry")
        expiry = _parse_date_safe(expiry_str) if expiry_str else None
        if expiry:
            days_left = (expiry - today).days
            if days_left < 0:
                risks.append({"label": "Insurance expired", "tone": "risk"})
            elif days_left <= 30:
                risks.append({"label": f"Insurance expires in {days_left} days", "tone": "warn"})
        else:
            risks.append({"label": "Could not find insurance expiry date", "tone": "warn"})

    if kind == "contract" and not specific.get("signed"):
        risks.append({"label": "No signature found", "tone": "warn"})

    if kind == "invoice" and specific.get("due_date"):
        due = _parse_date_safe(specific["due_date"])
        if due and due < today:
            risks.append({"label": "Invoice past due", "tone": "risk"})

    return risks


def extract_fields(text: str, kind: str) -> dict:
    """Main entry point used by the API layer."""
    generic = extract_generic_fields(text)
    specific = extract_kind_specific_fields(text, kind)
    risks = compute_risks(kind, generic, specific)
    return {"generic": generic, "specific": specific, "risks": risks}
