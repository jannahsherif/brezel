from .classify import classify_document
from .extract_text import extract_text
from .fields import extract_fields


def process_document(path: str, filename: str = "") -> dict:
    """Run the full local pipeline on a file already saved to disk.

    Returns everything the API needs to store: the raw text (so it can be
    re-processed later without re-uploading), which kind it was classified
    as, whether OCR was needed, the structured fields, and derived risks.
    """
    extraction = extract_text(path)
    kind = classify_document(extraction.text, filename)
    fields = extract_fields(extraction.text, kind)

    return {
        "kind": kind,
        "text": extraction.text,
        "used_ocr": extraction.used_ocr,
        "page_count": extraction.page_count,
        "fields": fields["generic"] | fields["specific"],
        "risks": fields["risks"],
    }
