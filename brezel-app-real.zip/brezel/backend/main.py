import json
import os
import shutil
import sqlite3
from datetime import date, datetime, timedelta

from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from db import get_conn, init_db, DB_PATH
from extraction import process_document

BASE_DIR = os.path.dirname(__file__)
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
PUBLIC_DIR = os.path.join(BASE_DIR, "public")
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = FastAPI(title="Brezel API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

init_db()


def now() -> str:
    return datetime.utcnow().isoformat()


def row_to_dict(row: sqlite3.Row) -> dict:
    return {k: row[k] for k in row.keys()}


# --------------------------------------------------------------------------
# Signup / signin (feature parity with the original Node prototype)
# --------------------------------------------------------------------------

class SignupBody(BaseModel):
    name: str
    email: str


class SigninBody(BaseModel):
    email: str


@app.post("/api/signup")
def signup(body: SignupBody):
    conn = get_conn()
    existing = conn.execute("SELECT * FROM signups WHERE email = ?", (body.email,)).fetchone()
    if existing:
        conn.close()
        return {"message": f"Welcome back, {existing['name']}! You're already signed up."}
    conn.execute(
        "INSERT INTO signups (name, email, created_at) VALUES (?, ?, ?)",
        (body.name, body.email, now()),
    )
    conn.commit()
    conn.close()
    return {"message": f"Welcome, {body.name}! Thanks for signing up for Brezel."}


@app.post("/api/signin")
def signin(body: SigninBody):
    conn = get_conn()
    row = conn.execute("SELECT * FROM signups WHERE email = ?", (body.email,)).fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="That email hasn't signed up yet.")
    return {"message": f"Good to see you again, {row['name']}!"}


@app.get("/api/signups")
def list_signups():
    conn = get_conn()
    rows = conn.execute("SELECT id, name, email, created_at FROM signups ORDER BY id DESC").fetchall()
    conn.close()
    return [row_to_dict(r) for r in rows]


# --------------------------------------------------------------------------
# Events
# --------------------------------------------------------------------------

class EventBody(BaseModel):
    name: str
    venue: str | None = None
    city: str | None = None
    event_date: str | None = None
    status: str = "planning"


@app.get("/api/events")
def list_events():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM events ORDER BY event_date").fetchall()
    conn.close()
    return [row_to_dict(r) for r in rows]


@app.post("/api/events")
def create_event(body: EventBody):
    conn = get_conn()
    cur = conn.execute(
        "INSERT INTO events (name, venue, city, event_date, status, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (body.name, body.venue, body.city, body.event_date, body.status, now()),
    )
    conn.commit()
    event_id = cur.lastrowid
    conn.close()
    return {"id": event_id}


@app.get("/api/events/{event_id}")
def get_event(event_id: int):
    conn = get_conn()
    row = conn.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Event not found")
    return row_to_dict(row)


@app.put("/api/events/{event_id}")
def update_event(event_id: int, body: EventBody):
    conn = get_conn()
    conn.execute(
        "UPDATE events SET name=?, venue=?, city=?, event_date=?, status=? WHERE id=?",
        (body.name, body.venue, body.city, body.event_date, body.status, event_id),
    )
    conn.commit()
    conn.close()
    return {"ok": True}


@app.delete("/api/events/{event_id}")
def delete_event(event_id: int):
    conn = get_conn()
    conn.execute("DELETE FROM events WHERE id = ?", (event_id,))
    conn.commit()
    conn.close()
    return {"ok": True}


# --------------------------------------------------------------------------
# Vendors
# --------------------------------------------------------------------------

class VendorBody(BaseModel):
    name: str
    email: str | None = None
    phone: str | None = None
    contract_status: str = "pending"
    deposit_status: str = "pending"
    insurance_status: str = "pending"
    insurance_expiry: str | None = None


@app.get("/api/events/{event_id}/vendors")
def list_vendors(event_id: int):
    conn = get_conn()
    rows = conn.execute("SELECT * FROM vendors WHERE event_id = ? ORDER BY name", (event_id,)).fetchall()
    conn.close()
    return [row_to_dict(r) for r in rows]


@app.post("/api/events/{event_id}/vendors")
def create_vendor(event_id: int, body: VendorBody):
    conn = get_conn()
    cur = conn.execute(
        """INSERT INTO vendors
           (event_id, name, email, phone, contract_status, deposit_status, insurance_status, insurance_expiry, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (event_id, body.name, body.email, body.phone, body.contract_status,
         body.deposit_status, body.insurance_status, body.insurance_expiry, now()),
    )
    conn.commit()
    vendor_id = cur.lastrowid
    conn.close()
    return {"id": vendor_id}


@app.put("/api/vendors/{vendor_id}")
def update_vendor(vendor_id: int, body: VendorBody):
    conn = get_conn()
    conn.execute(
        """UPDATE vendors SET name=?, email=?, phone=?, contract_status=?, deposit_status=?,
           insurance_status=?, insurance_expiry=? WHERE id=?""",
        (body.name, body.email, body.phone, body.contract_status, body.deposit_status,
         body.insurance_status, body.insurance_expiry, vendor_id),
    )
    conn.commit()
    conn.close()
    return {"ok": True}


@app.delete("/api/vendors/{vendor_id}")
def delete_vendor(vendor_id: int):
    conn = get_conn()
    conn.execute("DELETE FROM vendors WHERE id = ?", (vendor_id,))
    conn.commit()
    conn.close()
    return {"ok": True}


# --------------------------------------------------------------------------
# Documents — the extraction pipeline lives here
# --------------------------------------------------------------------------

@app.get("/api/events/{event_id}/documents")
def list_documents(event_id: int):
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM documents WHERE event_id = ? ORDER BY uploaded_at DESC", (event_id,)
    ).fetchall()
    conn.close()
    out = []
    for r in rows:
        d = row_to_dict(r)
        d["fields"] = json.loads(d.pop("fields_json") or "{}")
        d["risks"] = json.loads(d.pop("risks_json") or "[]")
        d.pop("raw_text", None)  # keep list responses light
        out.append(d)
    return out


@app.get("/api/documents/{document_id}")
def get_document(document_id: int):
    conn = get_conn()
    row = conn.execute("SELECT * FROM documents WHERE id = ?", (document_id,)).fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Document not found")
    d = row_to_dict(row)
    d["fields"] = json.loads(d.pop("fields_json") or "{}")
    d["risks"] = json.loads(d.pop("risks_json") or "[]")
    return d


@app.post("/api/events/{event_id}/documents")
async def upload_document(event_id: int, file: UploadFile = File(...), vendor_id: int | None = Form(None)):
    conn = get_conn()
    event = conn.execute("SELECT id FROM events WHERE id = ?", (event_id,)).fetchone()
    if not event:
        conn.close()
        raise HTTPException(status_code=404, detail="Event not found")

    event_dir = os.path.join(UPLOAD_DIR, str(event_id))
    os.makedirs(event_dir, exist_ok=True)
    dest_path = os.path.join(event_dir, file.filename)
    with open(dest_path, "wb") as out:
        shutil.copyfileobj(file.file, out)

    try:
        result = process_document(dest_path, file.filename)
    except ValueError as e:
        conn.close()
        raise HTTPException(status_code=400, detail=str(e))

    status = "current" if not result["risks"] else "needs_review"

    cur = conn.execute(
        """INSERT INTO documents
           (event_id, vendor_id, name, kind, file_path, source, status, used_ocr,
            raw_text, fields_json, risks_json, uploaded_at)
           VALUES (?, ?, ?, ?, ?, 'upload', ?, ?, ?, ?, ?, ?)""",
        (
            event_id, vendor_id, file.filename, result["kind"], dest_path, status,
            int(result["used_ocr"]), result["text"], json.dumps(result["fields"]),
            json.dumps(result["risks"]), now(),
        ),
    )
    conn.commit()
    doc_id = cur.lastrowid
    conn.close()

    return get_document(doc_id)


@app.delete("/api/documents/{document_id}")
def delete_document(document_id: int):
    conn = get_conn()
    row = conn.execute("SELECT file_path FROM documents WHERE id = ?", (document_id,)).fetchone()
    if row and row["file_path"] and os.path.exists(row["file_path"]):
        os.remove(row["file_path"])
    conn.execute("DELETE FROM documents WHERE id = ?", (document_id,))
    conn.commit()
    conn.close()
    return {"ok": True}


# --------------------------------------------------------------------------
# Tasks
# --------------------------------------------------------------------------

class TaskBody(BaseModel):
    title: str
    owner: str | None = None
    due_date: str | None = None
    status: str = "due"
    related_document_id: int | None = None


@app.get("/api/events/{event_id}/tasks")
def list_tasks(event_id: int):
    conn = get_conn()
    rows = conn.execute("SELECT * FROM tasks WHERE event_id = ? ORDER BY due_date", (event_id,)).fetchall()
    conn.close()
    return [row_to_dict(r) for r in rows]


@app.post("/api/events/{event_id}/tasks")
def create_task(event_id: int, body: TaskBody):
    conn = get_conn()
    cur = conn.execute(
        """INSERT INTO tasks (event_id, title, owner, due_date, status, related_document_id, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (event_id, body.title, body.owner, body.due_date, body.status, body.related_document_id, now()),
    )
    conn.commit()
    task_id = cur.lastrowid
    conn.close()
    return {"id": task_id}


@app.put("/api/tasks/{task_id}")
def update_task(task_id: int, body: TaskBody):
    conn = get_conn()
    conn.execute(
        """UPDATE tasks SET title=?, owner=?, due_date=?, status=?, related_document_id=? WHERE id=?""",
        (body.title, body.owner, body.due_date, body.status, body.related_document_id, task_id),
    )
    conn.commit()
    conn.close()
    return {"ok": True}


@app.delete("/api/tasks/{task_id}")
def delete_task(task_id: int):
    conn = get_conn()
    conn.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
    conn.commit()
    conn.close()
    return {"ok": True}


# --------------------------------------------------------------------------
# Budget
# --------------------------------------------------------------------------

class BudgetItemBody(BaseModel):
    category: str
    planned: float = 0
    actual: float = 0


@app.get("/api/events/{event_id}/budget")
def list_budget(event_id: int):
    conn = get_conn()
    rows = conn.execute("SELECT * FROM budget_items WHERE event_id = ?", (event_id,)).fetchall()
    conn.close()
    return [row_to_dict(r) for r in rows]


@app.post("/api/events/{event_id}/budget")
def create_budget_item(event_id: int, body: BudgetItemBody):
    conn = get_conn()
    cur = conn.execute(
        "INSERT INTO budget_items (event_id, category, planned, actual) VALUES (?, ?, ?, ?)",
        (event_id, body.category, body.planned, body.actual),
    )
    conn.commit()
    item_id = cur.lastrowid
    conn.close()
    return {"id": item_id}


@app.put("/api/budget/{item_id}")
def update_budget_item(item_id: int, body: BudgetItemBody):
    conn = get_conn()
    conn.execute(
        "UPDATE budget_items SET category=?, planned=?, actual=? WHERE id=?",
        (body.category, body.planned, body.actual, item_id),
    )
    conn.commit()
    conn.close()
    return {"ok": True}


@app.delete("/api/budget/{item_id}")
def delete_budget_item(item_id: int):
    conn = get_conn()
    conn.execute("DELETE FROM budget_items WHERE id = ?", (item_id,))
    conn.commit()
    conn.close()
    return {"ok": True}


# --------------------------------------------------------------------------
# Computed: risks + dashboard summary (this is what replaces the old mock
# "copilot"/insight numbers — every figure here comes from real rows)
# --------------------------------------------------------------------------

@app.get("/api/events/{event_id}/risks")
def event_risks(event_id: int):
    conn = get_conn()
    risks = []

    docs = conn.execute("SELECT * FROM documents WHERE event_id = ?", (event_id,)).fetchall()
    for d in docs:
        for r in json.loads(d["risks_json"] or "[]"):
            risks.append({**r, "source": "document", "document_id": d["id"], "document_name": d["name"]})

    vendors = conn.execute("SELECT * FROM vendors WHERE event_id = ?", (event_id,)).fetchall()
    today = date.today()
    for v in vendors:
        if v["insurance_expiry"]:
            try:
                exp = datetime.fromisoformat(v["insurance_expiry"]).date()
                days_left = (exp - today).days
                if days_left <= 30:
                    tone = "risk" if days_left < 0 else "warn"
                    risks.append({
                        "label": f"{v['name']}: insurance expires in {days_left} days",
                        "tone": tone, "source": "vendor", "vendor_id": v["id"],
                    })
            except ValueError:
                pass
        if v["contract_status"] != "signed":
            risks.append({
                "label": f"{v['name']}: contract not yet signed",
                "tone": "warn", "source": "vendor", "vendor_id": v["id"],
            })

    tasks = conn.execute(
        "SELECT * FROM tasks WHERE event_id = ? AND status != 'done'", (event_id,)
    ).fetchall()
    unowned = [t for t in tasks if not t["owner"]]
    if unowned:
        risks.append({
            "label": f"{len(unowned)} task(s) have no owner",
            "tone": "warn", "source": "tasks",
        })

    budget = conn.execute("SELECT * FROM budget_items WHERE event_id = ?", (event_id,)).fetchall()
    total_planned = sum(b["planned"] for b in budget)
    total_actual = sum(b["actual"] for b in budget)
    if total_planned and total_actual > total_planned:
        over_pct = round((total_actual - total_planned) / total_planned * 100, 1)
        risks.append({
            "label": f"Budget is {over_pct}% over plan",
            "tone": "risk", "source": "budget",
        })

    conn.close()
    return risks


@app.get("/api/events/{event_id}/summary")
def event_summary(event_id: int):
    conn = get_conn()
    vendors = conn.execute("SELECT * FROM vendors WHERE event_id = ?", (event_id,)).fetchall()
    docs = conn.execute("SELECT * FROM documents WHERE event_id = ?", (event_id,)).fetchall()
    tasks = conn.execute("SELECT * FROM tasks WHERE event_id = ?", (event_id,)).fetchall()
    budget = conn.execute("SELECT * FROM budget_items WHERE event_id = ?", (event_id,)).fetchall()
    conn.close()

    vendors_cleared = len([
        v for v in vendors
        if v["contract_status"] == "signed" and v["deposit_status"] == "paid" and v["insurance_status"] == "cleared"
    ])
    tasks_blocked = len([t for t in tasks if t["status"] == "blocked"])
    docs_needing_review = len([d for d in docs if d["status"] == "needs_review"])
    total_planned = sum(b["planned"] for b in budget)
    total_actual = sum(b["actual"] for b in budget)

    risks = event_risks(event_id)

    return {
        "vendor_count": len(vendors),
        "vendors_cleared": vendors_cleared,
        "vendors_need_review": len(vendors) - vendors_cleared,
        "document_count": len(docs),
        "documents_needing_review": docs_needing_review,
        "task_count": len(tasks),
        "tasks_blocked": tasks_blocked,
        "budget_planned": total_planned,
        "budget_actual": total_actual,
        "budget_variance_pct": round((total_actual - total_planned) / total_planned * 100, 1) if total_planned else 0,
        "risk_count": len(risks),
    }


# --------------------------------------------------------------------------
# Static file serving: the marketing landing page + the app SPA
# --------------------------------------------------------------------------

# NOTE: "/uploads" (brand assets like the logo) lives under public/ and is
# served by the catch-all "/" mount below. Uploaded *documents* are served
# from a different path, "/files", to avoid clashing with it.
app.mount("/files", StaticFiles(directory=UPLOAD_DIR), name="uploaded_documents")
app.mount("/app", StaticFiles(directory=os.path.join(PUBLIC_DIR, "app"), html=True), name="app_spa")
app.mount("/", StaticFiles(directory=PUBLIC_DIR, html=True), name="site")

