// Brezel — vanilla-JS SPA. No build step, no framework: just fetch() against
// the real FastAPI backend in ../main.py.

const root = document.getElementById('root');

// ---------------------------------------------------------------- API layer

const api = {
  async get(path) {
    const r = await fetch(`/api${path}`);
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail || r.statusText);
    return r.json();
  },
  async send(method, path, body) {
    const r = await fetch(`/api${path}`, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail || r.statusText);
    return r.json();
  },
  post(path, body) { return this.send('POST', path, body); },
  put(path, body) { return this.send('PUT', path, body); },
  del(path) { return this.send('DELETE', path); },
  async upload(path, formData) {
    const r = await fetch(`/api${path}`, { method: 'POST', body: formData });
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail || r.statusText);
    return r.json();
  },
};

function toast(msg) {
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 2600);
}

function esc(s) {
  if (s === null || s === undefined) return '';
  return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function fmtMoney(n) {
  return '$' + Number(n || 0).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

function fmtDate(s) {
  if (!s) return '—';
  try { return new Date(s).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }); }
  catch { return s; }
}

// ---------------------------------------------------------------- Router

const routes = [];
function route(pattern, handler) { routes.push({ pattern, handler }); }

function matchRoute(hash) {
  for (const { pattern, handler } of routes) {
    const names = [];
    const regexStr = '^' + pattern.replace(/:[^/]+/g, m => { names.push(m.slice(1)); return '([^/]+)'; }) + '$';
    const match = hash.match(new RegExp(regexStr));
    if (match) {
      const params = {};
      names.forEach((n, i) => { params[n] = match[i + 1]; });
      return { handler, params };
    }
  }
  return null;
}

async function render() {
  const hash = (location.hash || '#/').replace(/^#/, '');
  const matched = matchRoute(hash);
  if (!matched) { location.hash = '#/'; return; }
  try {
    await matched.handler(matched.params);
  } catch (e) {
    root.innerHTML = shellHtml('', `<div class="empty"><p>Something went wrong: ${esc(e.message)}</p></div>`);
  }
}
window.addEventListener('hashchange', render);

// ---------------------------------------------------------------- Shell (sidebar + layout)

function shellHtml(activeNav, contentHtml, eventId) {
  const eventNav = eventId ? `
    <div class="nav-section-label">This event</div>
    <a class="nav-link ${activeNav === 'dashboard' ? 'active' : ''}" href="#/events/${eventId}">Dashboard</a>
    <a class="nav-link ${activeNav === 'documents' ? 'active' : ''}" href="#/events/${eventId}/documents">Documents</a>
    <a class="nav-link ${activeNav === 'vendors' ? 'active' : ''}" href="#/events/${eventId}/vendors">Vendors</a>
    <a class="nav-link ${activeNav === 'tasks' ? 'active' : ''}" href="#/events/${eventId}/tasks">Tasks</a>
    <a class="nav-link ${activeNav === 'budget' ? 'active' : ''}" href="#/events/${eventId}/budget">Budget</a>
  ` : '';

  return `
    <div class="sidebar">
      <div class="brand"><img src="/uploads/brezel_logo_gradient_ready.svg" alt="" /> Brezel</div>
      <a class="nav-link ${activeNav === 'portfolio' ? 'active' : ''}" href="#/">All events</a>
      ${eventNav}
    </div>
    <div class="main">${contentHtml}</div>
  `;
}

// ---------------------------------------------------------------- Portfolio (events list)

route('/', async () => {
  const events = await api.get('/events');
  const cards = events.map(e => `
    <div class="card event-card" data-nav="#/events/${e.id}">
      <div class="stat-label">${esc(e.city || '')}${e.city && e.venue ? ' · ' : ''}${esc(e.venue || '')}</div>
      <div class="stat-value" style="font-size:18px">${esc(e.name)}</div>
      <div class="stat-sub">${fmtDate(e.event_date)} · <span class="badge neutral">${esc(e.status)}</span></div>
    </div>
  `).join('') || `<div class="empty">No events yet. Create your first one.</div>`;

  root.innerHTML = shellHtml('portfolio', `
    <div class="page-header">
      <div><h1>All events</h1><div class="sub">Every event Brezel is tracking for you.</div></div>
      <button class="btn" id="new-event-btn">+ New event</button>
    </div>
    <div class="grid cols-3">${cards}</div>
  `);

  root.querySelectorAll('[data-nav]').forEach(el => el.addEventListener('click', () => location.hash = el.dataset.nav));
  document.getElementById('new-event-btn').addEventListener('click', () => openEventModal());
});

function openEventModal(existing) {
  const backdrop = document.createElement('div');
  backdrop.className = 'modal-backdrop';
  backdrop.innerHTML = `
    <div class="modal">
      <h2>${existing ? 'Edit event' : 'New event'}</h2>
      <div class="field"><label>Event name</label><input class="input" id="f-name" value="${esc(existing?.name || '')}" placeholder="Fig & Vine Gala" /></div>
      <div class="field"><label>Venue</label><input class="input" id="f-venue" value="${esc(existing?.venue || '')}" placeholder="The Barbican" /></div>
      <div class="field"><label>City</label><input class="input" id="f-city" value="${esc(existing?.city || '')}" placeholder="London" /></div>
      <div class="field"><label>Date</label><input class="input" type="date" id="f-date" value="${existing?.event_date ? existing.event_date.slice(0,10) : ''}" /></div>
      <div class="field"><label>Status</label>
        <select id="f-status">
          ${['planning','confirmed','live','completed'].map(s => `<option value="${s}" ${existing?.status === s ? 'selected' : ''}>${s}</option>`).join('')}
        </select>
      </div>
      <div class="modal-actions">
        <button class="btn secondary" id="cancel-btn">Cancel</button>
        <button class="btn" id="save-btn">${existing ? 'Save' : 'Create'}</button>
      </div>
    </div>
  `;
  document.body.appendChild(backdrop);
  backdrop.addEventListener('click', e => { if (e.target === backdrop) backdrop.remove(); });
  backdrop.querySelector('#cancel-btn').addEventListener('click', () => backdrop.remove());
  backdrop.querySelector('#save-btn').addEventListener('click', async () => {
    const body = {
      name: document.getElementById('f-name').value.trim(),
      venue: document.getElementById('f-venue').value.trim(),
      city: document.getElementById('f-city').value.trim(),
      event_date: document.getElementById('f-date').value || null,
      status: document.getElementById('f-status').value,
    };
    if (!body.name) { toast('Event name is required'); return; }
    if (existing) {
      await api.put(`/events/${existing.id}`, body);
      toast('Event updated');
    } else {
      const { id } = await api.post('/events', body);
      toast('Event created');
      backdrop.remove();
      location.hash = `#/events/${id}`;
      return;
    }
    backdrop.remove();
    render();
  });
}

// ---------------------------------------------------------------- Event dashboard

route('/events/:id', async ({ id }) => {
  const [event, summary, risks] = await Promise.all([
    api.get(`/events/${id}`), api.get(`/events/${id}/summary`), api.get(`/events/${id}/risks`),
  ]);

  const riskItems = risks.length
    ? risks.map(r => `<div class="risk-item"><span class="risk-dot ${r.tone}"></span>${esc(r.label)}</div>`).join('')
    : `<div class="empty" style="padding:20px">Nothing needs attention right now.</div>`;

  root.innerHTML = shellHtml('dashboard', `
    <div class="page-header">
      <div><h1>${esc(event.name)}</h1><div class="sub">${esc(event.venue || '')}${event.venue && event.city ? ', ' : ''}${esc(event.city || '')} · ${fmtDate(event.event_date)}</div></div>
      <button class="btn secondary" id="edit-event-btn">Edit event</button>
    </div>
    <div class="grid cols-4" style="margin-bottom:20px">
      <div class="card"><div class="stat-label">Vendors cleared</div><div class="stat-value">${summary.vendors_cleared}/${summary.vendor_count}</div><div class="stat-sub ${summary.vendors_need_review ? 'risk' : 'ok'}">${summary.vendors_need_review} need review</div></div>
      <div class="card"><div class="stat-label">Documents</div><div class="stat-value">${summary.document_count}</div><div class="stat-sub ${summary.documents_needing_review ? 'risk' : 'ok'}">${summary.documents_needing_review} need review</div></div>
      <div class="card"><div class="stat-label">Tasks blocked</div><div class="stat-value">${summary.tasks_blocked}</div><div class="stat-sub">${summary.task_count} total</div></div>
      <div class="card"><div class="stat-label">Budget</div><div class="stat-value">${fmtMoney(summary.budget_actual)}</div><div class="stat-sub ${summary.budget_variance_pct > 0 ? 'risk' : 'ok'}">${summary.budget_variance_pct > 0 ? '+' : ''}${summary.budget_variance_pct}% vs plan</div></div>
    </div>
    <div class="card">
      <div class="stat-label" style="margin-bottom:10px">Needs attention (${risks.length})</div>
      ${riskItems}
    </div>
  `, id);

  document.getElementById('edit-event-btn').addEventListener('click', () => openEventModal(event));
});

// ---------------------------------------------------------------- Vendors

route('/events/:id/vendors', async ({ id }) => {
  const vendors = await api.get(`/events/${id}/vendors`);
  const statusBadge = s => `<span class="badge ${s === 'signed' || s === 'paid' || s === 'cleared' ? 'ok' : s === 'pending' ? 'warn' : 'neutral'}">${esc(s)}</span>`;

  const rows = vendors.map(v => `
    <tr>
      <td>${esc(v.name)}</td>
      <td>${esc(v.email || '—')}</td>
      <td>${statusBadge(v.contract_status)}</td>
      <td>${statusBadge(v.deposit_status)}</td>
      <td>${statusBadge(v.insurance_status)}</td>
      <td>${fmtDate(v.insurance_expiry)}</td>
      <td><button class="btn secondary small" data-edit="${v.id}">Edit</button> <button class="btn danger small" data-del="${v.id}">Delete</button></td>
    </tr>
  `).join('');

  root.innerHTML = shellHtml('vendors', `
    <div class="page-header">
      <div><h1>Vendors</h1><div class="sub">Contracts, deposits, and insurance status.</div></div>
      <button class="btn" id="new-vendor-btn">+ Add vendor</button>
    </div>
    <div class="card" style="padding:0">
      ${vendors.length ? `<table><thead><tr><th>Name</th><th>Email</th><th>Contract</th><th>Deposit</th><th>Insurance</th><th>Expiry</th><th></th></tr></thead><tbody>${rows}</tbody></table>` : `<div class="empty">No vendors yet.</div>`}
    </div>
  `, id);

  document.getElementById('new-vendor-btn').addEventListener('click', () => openVendorModal(id));
  root.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => {
    openVendorModal(id, vendors.find(v => v.id == b.dataset.edit));
  }));
  root.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', async () => {
    if (!confirm('Delete this vendor?')) return;
    await api.del(`/vendors/${b.dataset.del}`);
    render();
  }));
});

function openVendorModal(eventId, existing) {
  const backdrop = document.createElement('div');
  backdrop.className = 'modal-backdrop';
  const statusOpts = (opts, val) => opts.map(o => `<option value="${o}" ${val === o ? 'selected' : ''}>${o}</option>`).join('');
  backdrop.innerHTML = `
    <div class="modal">
      <h2>${existing ? 'Edit vendor' : 'Add vendor'}</h2>
      <div class="field"><label>Name</label><input class="input" id="f-name" value="${esc(existing?.name || '')}" placeholder="Fig & Vine Catering" /></div>
      <div class="field"><label>Email</label><input class="input" id="f-email" value="${esc(existing?.email || '')}" /></div>
      <div class="field"><label>Phone</label><input class="input" id="f-phone" value="${esc(existing?.phone || '')}" /></div>
      <div class="field"><label>Contract status</label><select id="f-contract">${statusOpts(['pending','signed'], existing?.contract_status)}</select></div>
      <div class="field"><label>Deposit status</label><select id="f-deposit">${statusOpts(['pending','paid'], existing?.deposit_status)}</select></div>
      <div class="field"><label>Insurance status</label><select id="f-insurance">${statusOpts(['pending','cleared'], existing?.insurance_status)}</select></div>
      <div class="field"><label>Insurance expiry</label><input class="input" type="date" id="f-expiry" value="${existing?.insurance_expiry ? existing.insurance_expiry.slice(0,10) : ''}" /></div>
      <div class="modal-actions">
        <button class="btn secondary" id="cancel-btn">Cancel</button>
        <button class="btn" id="save-btn">${existing ? 'Save' : 'Add'}</button>
      </div>
    </div>
  `;
  document.body.appendChild(backdrop);
  backdrop.addEventListener('click', e => { if (e.target === backdrop) backdrop.remove(); });
  backdrop.querySelector('#cancel-btn').addEventListener('click', () => backdrop.remove());
  backdrop.querySelector('#save-btn').addEventListener('click', async () => {
    const body = {
      name: document.getElementById('f-name').value.trim(),
      email: document.getElementById('f-email').value.trim(),
      phone: document.getElementById('f-phone').value.trim(),
      contract_status: document.getElementById('f-contract').value,
      deposit_status: document.getElementById('f-deposit').value,
      insurance_status: document.getElementById('f-insurance').value,
      insurance_expiry: document.getElementById('f-expiry').value || null,
    };
    if (!body.name) { toast('Vendor name is required'); return; }
    if (existing) await api.put(`/vendors/${existing.id}`, body);
    else await api.post(`/events/${eventId}/vendors`, body);
    backdrop.remove();
    render();
  });
}

// ---------------------------------------------------------------- Documents

route('/events/:id/documents', async ({ id }) => {
  const docs = await api.get(`/events/${id}/documents`);
  const statusBadge = s => `<span class="badge ${s === 'current' ? 'ok' : 'warn'}">${s === 'current' ? 'current' : 'needs review'}</span>`;
  const kindLabel = k => ({ insurance: 'Insurance', invoice: 'Invoice', contract: 'Contract', run_of_show: 'Run of show', menu: 'Menu', other: 'Other' }[k] || k);

  const rows = docs.map(d => `
    <tr class="clickable" data-open="${d.id}">
      <td>${esc(d.name)}</td>
      <td><span class="badge neutral">${kindLabel(d.kind)}</span></td>
      <td>${statusBadge(d.status)}</td>
      <td>${d.risks.length ? d.risks.map(r => `<span class="badge ${r.tone}">${esc(r.label)}</span>`).join(' ') : '—'}</td>
      <td>${d.used_ocr ? 'OCR' : 'text'}</td>
      <td>${fmtDate(d.uploaded_at)}</td>
      <td><button class="btn danger small" data-del="${d.id}">Delete</button></td>
    </tr>
  `).join('');

  root.innerHTML = shellHtml('documents', `
    <div class="page-header">
      <div><h1>Documents</h1><div class="sub">Upload a contract, invoice, insurance certificate, run-of-show, or menu — Brezel reads it locally and pulls out the fields that matter.</div></div>
    </div>
    <div class="dropzone" id="dropzone">
      <div>Drag a file here, or <label style="color:var(--color-accent-hover);font-weight:600;cursor:pointer">browse<input type="file" id="file-input" accept=".pdf,.png,.jpg,.jpeg,.txt" /></label></div>
      <div style="font-size:12px;margin-top:6px">PDF, PNG, JPG, or TXT. Scanned files are OCR'd automatically, all on this server — no external API calls.</div>
      <div id="upload-status" style="margin-top:10px;font-size:13px"></div>
    </div>
    <div class="card" style="padding:0">
      ${docs.length ? `<table><thead><tr><th>Name</th><th>Kind</th><th>Status</th><th>Flags</th><th>Source</th><th>Uploaded</th><th></th></tr></thead><tbody>${rows}</tbody></table>` : `<div class="empty">No documents yet. Upload one above.</div>`}
    </div>
  `, id);

  const dropzone = document.getElementById('dropzone');
  const fileInput = document.getElementById('file-input');
  const statusEl = document.getElementById('upload-status');

  async function doUpload(file) {
    statusEl.textContent = `Processing ${file.name} locally (extracting text${/\.(png|jpe?g)$/i.test(file.name) ? ' + OCR' : ''})…`;
    const fd = new FormData();
    fd.append('file', file);
    try {
      const doc = await api.upload(`/events/${id}/documents`, fd);
      statusEl.textContent = '';
      toast(`Classified as "${kindLabel(doc.kind)}"${doc.used_ocr ? ' (OCR used)' : ''}`);
      render();
    } catch (e) {
      statusEl.textContent = `Failed: ${e.message}`;
    }
  }

  fileInput.addEventListener('change', () => { if (fileInput.files[0]) doUpload(fileInput.files[0]); });
  ['dragenter', 'dragover'].forEach(evt => dropzone.addEventListener(evt, e => { e.preventDefault(); dropzone.classList.add('dragover'); }));
  ['dragleave', 'drop'].forEach(evt => dropzone.addEventListener(evt, e => { e.preventDefault(); dropzone.classList.remove('dragover'); }));
  dropzone.addEventListener('drop', e => { const f = e.dataTransfer.files[0]; if (f) doUpload(f); });

  root.querySelectorAll('[data-open]').forEach(tr => tr.addEventListener('click', e => {
    if (e.target.closest('[data-del]')) return;
    location.hash = `#/events/${id}/documents/${tr.dataset.open}`;
  }));
  root.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', async (e) => {
    e.stopPropagation();
    if (!confirm('Delete this document?')) return;
    await api.del(`/documents/${b.dataset.del}`);
    render();
  }));
});

route('/events/:id/documents/:docId', async ({ id, docId }) => {
  const doc = await api.get(`/documents/${docId}`);
  const kindLabel = k => ({ insurance: 'Insurance', invoice: 'Invoice', contract: 'Contract', run_of_show: 'Run of show', menu: 'Menu', other: 'Other' }[k] || k);

  const fieldRows = Object.entries(doc.fields || {}).map(([k, v]) => `
    <div class="kv"><div class="k">${esc(k)}</div><div>${Array.isArray(v) ? esc(v.join(', ')) || '—' : (v === null || v === '' ? '—' : esc(String(v)))}</div></div>
  `).join('');

  const riskRows = (doc.risks || []).length
    ? doc.risks.map(r => `<div class="risk-item"><span class="risk-dot ${r.tone}"></span>${esc(r.label)}</div>`).join('')
    : `<div class="empty" style="padding:14px">No flags on this document.</div>`;

  root.innerHTML = shellHtml('documents', `
    <div class="page-header">
      <div><h1>${esc(doc.name)}</h1><div class="sub"><a href="#/events/${id}/documents" style="color:var(--color-accent-hover)">← Back to documents</a></div></div>
      <span class="badge neutral">${kindLabel(doc.kind)}</span>
    </div>
    <div class="grid cols-2" style="align-items:start">
      <div class="card">
        <div class="stat-label" style="margin-bottom:10px">Extracted fields</div>
        ${fieldRows || '<div class="empty">Nothing extracted.</div>'}
      </div>
      <div class="card">
        <div class="stat-label" style="margin-bottom:10px">Flags</div>
        ${riskRows}
      </div>
    </div>
    <div class="card" style="margin-top:14px">
      <div class="stat-label" style="margin-bottom:10px">Raw extracted text ${doc.used_ocr ? '(via OCR)' : '(from text layer)'}</div>
      <textarea readonly style="width:100%;min-height:260px">${esc(doc.raw_text || '')}</textarea>
    </div>
  `, id);
});

// ---------------------------------------------------------------- Tasks

route('/events/:id/tasks', async ({ id }) => {
  const tasks = await api.get(`/events/${id}/tasks`);
  const badge = s => `<span class="badge ${s === 'done' ? 'ok' : s === 'blocked' ? 'risk' : 'warn'}">${esc(s)}</span>`;

  const rows = tasks.map(t => `
    <tr>
      <td>${esc(t.title)}</td>
      <td>${esc(t.owner || '—')}</td>
      <td>${fmtDate(t.due_date)}</td>
      <td>
        <select data-status="${t.id}">
          ${['due','blocked','done'].map(s => `<option value="${s}" ${t.status === s ? 'selected' : ''}>${s}</option>`).join('')}
        </select>
      </td>
      <td><button class="btn danger small" data-del="${t.id}">Delete</button></td>
    </tr>
  `).join('');

  root.innerHTML = shellHtml('tasks', `
    <div class="page-header">
      <div><h1>Tasks</h1><div class="sub">What's blocked, what's due, what's done.</div></div>
      <button class="btn" id="new-task-btn">+ Add task</button>
    </div>
    <div class="card" style="padding:0">
      ${tasks.length ? `<table><thead><tr><th>Task</th><th>Owner</th><th>Due</th><th>Status</th><th></th></tr></thead><tbody>${rows}</tbody></table>` : `<div class="empty">No tasks yet.</div>`}
    </div>
  `, id);

  document.getElementById('new-task-btn').addEventListener('click', () => openTaskModal(id));
  root.querySelectorAll('[data-status]').forEach(sel => sel.addEventListener('change', async () => {
    const t = tasks.find(t => t.id == sel.dataset.status);
    await api.put(`/tasks/${t.id}`, { ...t, status: sel.value });
    render();
  }));
  root.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', async () => {
    if (!confirm('Delete this task?')) return;
    await api.del(`/tasks/${b.dataset.del}`);
    render();
  }));
});

function openTaskModal(eventId) {
  const backdrop = document.createElement('div');
  backdrop.className = 'modal-backdrop';
  backdrop.innerHTML = `
    <div class="modal">
      <h2>Add task</h2>
      <div class="field"><label>Title</label><input class="input" id="f-title" placeholder="Confirm dietary list with caterer" /></div>
      <div class="field"><label>Owner</label><input class="input" id="f-owner" placeholder="Optional" /></div>
      <div class="field"><label>Due date</label><input class="input" type="date" id="f-due" /></div>
      <div class="modal-actions">
        <button class="btn secondary" id="cancel-btn">Cancel</button>
        <button class="btn" id="save-btn">Add</button>
      </div>
    </div>
  `;
  document.body.appendChild(backdrop);
  backdrop.addEventListener('click', e => { if (e.target === backdrop) backdrop.remove(); });
  backdrop.querySelector('#cancel-btn').addEventListener('click', () => backdrop.remove());
  backdrop.querySelector('#save-btn').addEventListener('click', async () => {
    const title = document.getElementById('f-title').value.trim();
    if (!title) { toast('Title is required'); return; }
    await api.post(`/events/${eventId}/tasks`, {
      title, owner: document.getElementById('f-owner').value.trim() || null,
      due_date: document.getElementById('f-due').value || null, status: 'due',
    });
    backdrop.remove();
    render();
  });
}

// ---------------------------------------------------------------- Budget

route('/events/:id/budget', async ({ id }) => {
  const items = await api.get(`/events/${id}/budget`);
  const totalPlanned = items.reduce((s, i) => s + i.planned, 0);
  const totalActual = items.reduce((s, i) => s + i.actual, 0);

  const rows = items.map(i => {
    const variance = i.planned ? Math.round((i.actual - i.planned) / i.planned * 100) : 0;
    return `
    <tr>
      <td>${esc(i.category)}</td>
      <td>${fmtMoney(i.planned)}</td>
      <td>${fmtMoney(i.actual)}</td>
      <td class="${variance > 0 ? 'risk' : 'ok'}" style="font-weight:600">${variance > 0 ? '+' : ''}${variance}%</td>
      <td><button class="btn secondary small" data-edit="${i.id}">Edit</button> <button class="btn danger small" data-del="${i.id}">Delete</button></td>
    </tr>`;
  }).join('');

  root.innerHTML = shellHtml('budget', `
    <div class="page-header">
      <div><h1>Budget</h1><div class="sub">Planned vs. actual, by category.</div></div>
      <button class="btn" id="new-item-btn">+ Add category</button>
    </div>
    <div class="grid cols-3" style="margin-bottom:20px">
      <div class="card"><div class="stat-label">Planned</div><div class="stat-value">${fmtMoney(totalPlanned)}</div></div>
      <div class="card"><div class="stat-label">Actual</div><div class="stat-value">${fmtMoney(totalActual)}</div></div>
      <div class="card"><div class="stat-label">Variance</div><div class="stat-value ${totalActual > totalPlanned ? 'risk' : ''}">${totalPlanned ? Math.round((totalActual - totalPlanned) / totalPlanned * 100) : 0}%</div></div>
    </div>
    <div class="card" style="padding:0">
      ${items.length ? `<table><thead><tr><th>Category</th><th>Planned</th><th>Actual</th><th>Variance</th><th></th></tr></thead><tbody>${rows}</tbody></table>` : `<div class="empty">No budget categories yet.</div>`}
    </div>
  `, id);

  document.getElementById('new-item-btn').addEventListener('click', () => openBudgetModal(id));
  root.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => {
    openBudgetModal(id, items.find(i => i.id == b.dataset.edit));
  }));
  root.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', async () => {
    if (!confirm('Delete this category?')) return;
    await api.del(`/budget/${b.dataset.del}`);
    render();
  }));
});

function openBudgetModal(eventId, existing) {
  const backdrop = document.createElement('div');
  backdrop.className = 'modal-backdrop';
  backdrop.innerHTML = `
    <div class="modal">
      <h2>${existing ? 'Edit category' : 'Add category'}</h2>
      <div class="field"><label>Category</label><input class="input" id="f-cat" value="${esc(existing?.category || '')}" placeholder="Catering" /></div>
      <div class="field"><label>Planned ($)</label><input class="input" type="number" id="f-planned" value="${existing?.planned ?? 0}" /></div>
      <div class="field"><label>Actual ($)</label><input class="input" type="number" id="f-actual" value="${existing?.actual ?? 0}" /></div>
      <div class="modal-actions">
        <button class="btn secondary" id="cancel-btn">Cancel</button>
        <button class="btn" id="save-btn">${existing ? 'Save' : 'Add'}</button>
      </div>
    </div>
  `;
  document.body.appendChild(backdrop);
  backdrop.addEventListener('click', e => { if (e.target === backdrop) backdrop.remove(); });
  backdrop.querySelector('#cancel-btn').addEventListener('click', () => backdrop.remove());
  backdrop.querySelector('#save-btn').addEventListener('click', async () => {
    const body = {
      category: document.getElementById('f-cat').value.trim(),
      planned: parseFloat(document.getElementById('f-planned').value) || 0,
      actual: parseFloat(document.getElementById('f-actual').value) || 0,
    };
    if (!body.category) { toast('Category name is required'); return; }
    if (existing) await api.put(`/budget/${existing.id}`, body);
    else await api.post(`/events/${eventId}/budget`, body);
    backdrop.remove();
    render();
  });
}

render();
