# Brezel — real backend, zero API cost

This replaces the old demo (a compiled React bundle with fake, hardcoded
data) with an actual working app: a Python backend, a real SQLite database,
and a document-extraction pipeline that runs entirely on your own machine —
no OpenAI/Anthropic/Google Document AI calls, no per-page fees.

## What's real now

- **Events, Vendors, Documents, Tasks, Budget** — all backed by SQLite, all
  editable through the UI.
- **Document extraction pipeline**, 100% local:
  1. `pdfplumber` pulls text straight out of digital PDFs.
  2. If a PDF comes back nearly empty (i.e. it's a scan), it automatically
     falls back to OCR: `pdf2image` (via `poppler`) rasterizes the pages and
     `pytesseract` (Tesseract OCR) reads them.
  3. A regex/keyword classifier guesses the document type (contract,
     invoice, insurance certificate, run-of-show, menu).
  4. A second set of regexes pulls out fields per type — vendor name, dates,
     amounts, insurance expiry, due dates, whether a contract is signed —
     and turns anomalies into risk flags (expiring insurance, past-due
     invoices, unsigned contracts).
- **Risks and dashboard numbers are computed live** from real rows, not
  mocked — insurance expiring soon, unsigned contracts, unowned tasks,
  budget overruns.

## What's not built yet (on purpose, to keep this at $0 and in scope)

- **Connections** (Google Drive, Calendar, WhatsApp Business, Sheets) — these
  need real OAuth apps and API quotas with the respective providers, which
  is a different kind of cost (developer approval, rate limits) than the
  document pipeline. Wire these in later, one at a time, once you know
  which ones you actually need.
- **Copilot** — currently there's no chat/insights assistant. The `risks`
  and `summary` endpoints already compute the numbers a copilot would talk
  about; a simple version could just template sentences from them with no
  LLM at all.

## Running it

Requires Python 3.10+, and `tesseract-ocr` + `poppler-utils` installed on
the system (both are free, open-source, and available via your package
manager — e.g. `apt install tesseract-ocr poppler-utils` on Ubuntu/Debian,
`brew install tesseract poppler` on macOS).

```bash
cd backend
pip install -r requirements.txt
python -m uvicorn main:app --host 0.0.0.0 --port 8000
```

Then open **http://localhost:8000** — that's the landing page, and
**http://localhost:8000/app/** is the actual product.

A file at `backend/data/brezel.db` is created automatically on first run.
Uploaded documents are saved under `backend/uploads/<event_id>/`.

## Project layout

```
backend/
├── main.py              # FastAPI app: all routes, static file serving
├── db.py                # SQLite schema
├── extraction/
│   ├── extract_text.py  # pdfplumber + Tesseract OCR fallback
│   ├── classify.py      # regex document-type classifier
│   └── fields.py        # regex field extraction + risk flags
├── requirements.txt
├── public/
│   ├── index.html        # marketing/landing page (unchanged from original)
│   └── app/               # the actual app — vanilla JS, no build step
│       ├── index.html
│       ├── app.js
│       └── styles.css
└── uploads/               # uploaded documents land here (gitignored)
```

### Why a fresh frontend?

The uploaded prototype only contained a **compiled** React bundle
(`index-C4N9fX0f.js`) with every event, document, and risk baked in as
hardcoded mock data — there was no source code (`.jsx`/`.tsx`) and no
backend wiring for it at all. Editing a minified build isn't practical, so
this is a new, dependency-free JS app that talks to the real API, styled
with the same brand colors pulled from the original CSS.

## Upgrading extraction with a local LLM (still $0)

The regex pipeline is solid for well-structured documents but will miss
edge cases free-form documents throw at it. To add a local LLM without any
per-call cost:

```bash
# On your own machine/server — still free, just uses your own CPU/GPU
curl -fsSL https://ollama.com/install.sh | sh
ollama pull llama3.1
ollama serve
```

Then in `backend/extraction/fields.py`, add a function that calls
`ollama.chat(...)` with the extracted text and a prompt asking for JSON
fields, and merge its output over the regex result (regex first as a fast,
free pass; LLM to fill in anything regex left blank or ambiguous). The
docstring at the top of that file has a ready-to-adapt code snippet, and
`extract_fields()` is the only function the rest of the app calls — nothing
else needs to change.

## API reference

| Method & path | What it does |
|---|---|
| `POST /api/signup`, `/api/signin`, `GET /api/signups` | Same signup flow as the original prototype |
| `GET/POST /api/events`, `GET/PUT/DELETE /api/events/{id}` | Events |
| `GET/POST /api/events/{id}/vendors`, `PUT/DELETE /api/vendors/{id}` | Vendors |
| `GET/POST /api/events/{id}/documents`, `GET/DELETE /api/documents/{id}` | Documents — POST is a multipart file upload, runs the extraction pipeline synchronously and returns the result |
| `GET/POST /api/events/{id}/tasks`, `PUT/DELETE /api/tasks/{id}` | Tasks |
| `GET/POST /api/events/{id}/budget`, `PUT/DELETE /api/budget/{id}` | Budget categories |
| `GET /api/events/{id}/risks` | Computed risk flags across documents, vendors, tasks, budget |
| `GET /api/events/{id}/summary` | Computed dashboard numbers |
